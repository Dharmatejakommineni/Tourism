package travel.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class ProfilePanel extends JPanel implements ActionListener {

    private JTextField t1, t2, t3, t4, t5, t6;
    private JButton b1, b2, b3;
    private String username, user;
    private AdminHome a;
    private CustomerHome c;

    public ProfilePanel(AdminHome a, String username) {
        this.a = a;
        this.username = username;
        initializeUI();
        loadData("admin", username);
    }

    public ProfilePanel(CustomerHome c, String user) {
        this.c = c;
        this.user = user;
        initializeUI();
        loadData("customer", user);
    }

    private void initializeUI() {
        setLayout(null);

        JLabel l1 = new JLabel("Name:");
        l1.setBounds(50, 50, 150, 30);
        add(l1);

        t1 = new JTextField();
        t1.setBounds(200, 50, 150, 30);
        t1.setEditable(false);
        add(t1);

        JLabel l2 = new JLabel("Username:");
        l2.setBounds(50, 100, 150, 30);
        add(l2);

        t2 = new JTextField();
        t2.setBounds(200, 100, 150, 30);
        t2.setEditable(false);
        add(t2);

        JLabel l3 = new JLabel("Password:");
        l3.setBounds(50, 150, 150, 30);
        add(l3);

        t3 = new JTextField();
        t3.setBounds(200, 150, 150, 30);
        t3.setEditable(false);
        add(t3);

        JLabel l4 = new JLabel("Email:");
        l4.setBounds(50, 200, 150, 30);
        add(l4);

        t4 = new JTextField();
        t4.setBounds(200, 200, 150, 30);
        t4.setEditable(false);
        add(t4);

        JLabel l5 = new JLabel("Phone:");
        l5.setBounds(50, 250, 150, 30);
        add(l5);

        t5 = new JTextField();
        t5.setBounds(200, 250, 150, 30);
        t5.setEditable(false);
        add(t5);

        JLabel l6 = new JLabel("PAN Card:");
        l6.setBounds(50, 300, 150, 30);
        add(l6);

        t6 = new JTextField();
        t6.setBounds(200, 300, 150, 30);
        t6.setEditable(false);
        add(t6);

        b1 = new JButton("Edit Profile");
        b1.setBounds(50, 400, 120, 30);
        b1.addActionListener(this);
        add(b1);

        b2 = new JButton("Cancel");
        b2.setBounds(180, 400, 120, 30);
        b2.addActionListener(this);
        b2.setVisible(false);
        add(b2);

        b3 = new JButton("Save");
        b3.setBounds(310, 400, 120, 30);
        b3.addActionListener(this);
        b3.setVisible(false);
        add(b3);
    }

    private void loadData(String table, String username) {
        try {
            Conn conn = new Conn();
            String query = "SELECT * FROM " + table + " WHERE username = ?";
            PreparedStatement ps = conn.c.prepareStatement(query);
            ps.setString(1, username);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                t1.setText(rs.getString("name"));
                t2.setText(rs.getString("username"));
                t3.setText(rs.getString("password"));
                t4.setText(rs.getString("email"));
                t5.setText(rs.getString("phone"));
                t6.setText(rs.getString("pancard"));
            } else {
                JOptionPane.showMessageDialog(null, "No data found for the user.");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error loading data: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void updateDatabase(String table, String username) throws SQLException {
        Conn conn = new Conn();
        String query = "UPDATE " + table + " SET name = ?, username = ?, password = ?, email = ?, phone = ?, pancard = ? WHERE username = ?";
        PreparedStatement ps = conn.c.prepareStatement(query);
        ps.setString(1, t1.getText());
        ps.setString(2, t2.getText());
        ps.setString(3, t3.getText());
        ps.setString(4, t4.getText());
        ps.setString(5, t5.getText());
        ps.setString(6, t6.getText());
        ps.setString(7, username);
        ps.executeUpdate();
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == b1) {
            enableEditing(true);
        } else if (ae.getSource() == b2) {
            enableEditing(false);
        } else if (ae.getSource() == b3) {
            try {
                if (a != null) {
                    updateDatabase("admin", username);
                    JOptionPane.showMessageDialog(null, "Admin profile updated successfully.");
                } else if (c != null) {
                    updateDatabase("customer", user);
                    JOptionPane.showMessageDialog(null, "Customer profile updated successfully.");
                }
                enableEditing(false);
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Failed to update profile: " + e.getMessage());
                e.printStackTrace();
            }
        }
    }

    private void enableEditing(boolean enable) {
        t1.setEditable(enable);
        t3.setEditable(enable);
        t4.setEditable(enable);
        t5.setEditable(enable);
        t6.setEditable(enable);
        b2.setVisible(enable);
        b3.setVisible(enable);
        b1.setVisible(!enable);
    }
}
